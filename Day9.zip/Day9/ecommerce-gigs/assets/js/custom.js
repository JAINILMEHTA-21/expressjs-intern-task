$ = jQuery
jQuery(document).ready(function () {

    jQuery('.menu-top-menu-container').meanmenu({
        meanMenuContainer: '.main-navigation',
        meanScreenWidth: "1023",
        meanRevealPosition: "right",
    });
    $('.search-toggle').on('click', function (e) {
        e.preventDefault();

        $(this).parents('.header-search-section').toggleClass('search-active');
    });

    var windowWidth = jQuery(window).width();
    var nav = ".main-navigation";
    if (windowWidth > 1023) {
        jQuery(nav).off('mouseenter', 'li');
        jQuery(nav).off('mouseleave', 'li');
        jQuery(nav).off('click', 'li');
        jQuery(nav).off('click', 'a');
        jQuery(nav).on('mouseenter', 'li', function() {
            jQuery(this).children('ul').stop().hide();
            jQuery(this).children('ul').slideDown(400);
        });
        jQuery(nav).on('mouseleave', 'li', function() {
            jQuery(this).children('ul').stop().slideUp(350);
        });
    }     

    /* back-to-top button*/
    $('.back-to-top').hide();
    $('.back-to-top').on("click", function (e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: 0
        }, 'slow');
    });
    $(window).scroll(function () {
        var scrollheight = 400;
        if ($(window).scrollTop() > scrollheight) {
            $('.back-to-top').fadeIn();
        } else {
            $('.back-to-top').fadeOut();
        }
    });

    // slider
    var owllogo = $(".owl-slider-demo");
    owllogo.owlCarousel({
        items: 1,
        loop: true,
        nav: false,
        dots: true,
        smartSpeed: 900,
        autoplay: true,
        autoplayTimeout: 5000,
        fallbackEasing: 'easing',
        transitionStyle: "fade",
        autoplayHoverPause: true,
        animateOut: 'fadeOut'
    });

    var owllogo = $(".hot-deal-slider");
    owllogo.owlCarousel({
        items: 1,
        loop: true,
        nav: false,
        dots: true,
        smartSpeed: 900,
        autoplay: true,
        autoplayTimeout: 5000,
        fallbackEasing: 'easing',
        transitionStyle: "fade",
        autoplayHoverPause: true,
        animateOut: 'fadeOut'
    });

    var owllogo = $(".related-product-slider");
    owllogo.owlCarousel({
        items: 4,
        loop: true,
        nav: true,
        dots: false,
        smartSpeed: 900,
        autoplay: true,
        autoplayTimeout: 5000,
        fallbackEasing: 'easing',
        transitionStyle: "fade",
        autoplayHoverPause: true,
        animateOut: 'fadeOut',
        responsive: {
            0: {
                items: 1,
            },
            479: {
                items: 2,
            },
            767: {
                items: 3,
            },
            1000: {
                items: 4,
            }
        }
    });


    var owllogo = $(".testimonial-slider");
    owllogo.owlCarousel({
        items: 1,
        loop: true,
        nav: false,
        dots: true,
        smartSpeed: 900,
        autoplay: true,
        autoplayTimeout: 5000,
        fallbackEasing: 'easing',
        transitionStyle: "fade",
        autoplayHoverPause: true,
        animateOut: 'fadeOut'
    });


  var owllogo = $(".site-footer .partner-slider, #secondary .partner-slider");

  owllogo.owlCarousel({
    items: 1,
    loop: true,
    nav: true,
    dots: false,
    smartSpeed: 900,
    autoplay: true,
    autoplayTimeout: 5000,
    fallbackEasing: 'easing',
    transitionStyle: "fade",
    autoplayHoverPause: true,
    animateOut: 'fadeOut'
    
  });

  var owllogo = $(".partner-slider");

  owllogo.owlCarousel({
    items: 4,
    loop: true,
    nav: true,
    dots: false,
    smartSpeed: 900,
    autoplay: true,
    autoplayTimeout: 5000,
    fallbackEasing: 'easing',
    transitionStyle: "fade",
    autoplayHoverPause: true,
    animateOut: 'fadeOut',
    responsive: {
      0: {
        items: 1,
      },
      479: {
        items: 2,
      },
      767: {
        items: 3,
      },
      1000: {
        items: 4,
      }
    }
  });

  var owllogo = $(".site-footer .category-owl-slider, #secondary .category-owl-slider");

  owllogo.owlCarousel({
    items: 1,
    loop: true,
    nav: true,
    dots: false,
    smartSpeed: 900,
    autoplay: true,
    autoplayTimeout: 5000,
    fallbackEasing: 'easing',
    transitionStyle: "fade",
    autoplayHoverPause: true,
    animateOut: 'fadeOut'
  });

  var owllogo = $(".category-owl-slider");

  owllogo.owlCarousel({
    items: 3,
    loop: true,
    nav: true,
    dots: false,
    smartSpeed: 900,
    autoplay: true,
    autoplayTimeout: 5000,
    fallbackEasing: 'easing',
    transitionStyle: "fade",
    autoplayHoverPause: true,
    animateOut: 'fadeOut',
    responsive: {
      0: {
        items: 1,
      },
      600: {
        items: 2,
      },
      840: {
        items: 3,
      }
    }
  });


    // custom tab
    jQuery('.tabs .tab-links a').on('click', function (e) {
        var currentAttrValue = jQuery(this).attr('href');
        // Show/Hide Tabs
        jQuery('.tabs ' + currentAttrValue).fadeIn(400).siblings().hide();
        // Change/remove current tab to active
        jQuery(this).parent('li').addClass('active').siblings().removeClass('active');
        e.preventDefault();
    });

    // sticky sidebar
    jQuery('#primary , #secondary').theiaStickySidebar({
        // Settings
        additionalMarginTop: 30
    });

    //keyboard navigation for mean menu
    var myEvents = {
        click: function(e) {
            if ( jQuery(this).hasClass('menu-item-has-children') ) {
            jQuery(this).find('.mean-expand').addClass('mean-clicked');
            }
            jQuery(this).siblings('li').find('.mean-expand').removeClass('mean-clicked');
            jQuery(this).children('.sub-menu').show().end().siblings('li').find('ul').hide();

        },

        keydown: function(e) {
            e.stopPropagation();
            if (e.keyCode == 9) {
                if (!e.shiftKey &&
                ( jQuery('.mean-bar li').index( jQuery(this) ) == ( jQuery('.mean-bar li').length-1 ) ) ){
                    jQuery('.meanclose').trigger('click');
                }  else if( jQuery('.mean-bar li').index( jQuery(this) ) == 0 ) {
                    $('.meanclose').removeClass('onfocus');
                }
                else if (e.shiftKey && jQuery('.mean-bar li').index(jQuery(this)) === 0)
                    jQuery('.mean-bar ul:first > li:last').focus().blur();
            }
        },

        keyup: function(e) {
            e.stopPropagation();
            if (e.keyCode == 9) {
                if (myEvents.cancelKeyup) myEvents.cancelKeyup = false;
                else myEvents.click.apply(this, arguments);
            }
        }
    }
    jQuery(document)
    .on('click', 'li', myEvents.click)
    .on('keydown', 'li', myEvents.keydown)
    .on('keyup', 'li', myEvents.keyup);
    jQuery('.mean-bar li').each(function(i) { this.tabIndex = i; });  
});