<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ecommerce_Gigs
 */

?>
    </div>
    <footer id="colophon" class="site-footer">
    	<!-- footer starting from here -->
		<?php ecommerce_gigs_subscribe_widget();?> 
        <?php ecommerce_gigs_top_footer_widget();?> 
        <?php ecommerce_gigs_footer_widget();?> 
        <?php ecommerce_gigs_footer_copy_right();?> 
    </footer> <!-- footer ends here -->
    <div class="back-to-top">
        <a href="#masthead" title="<?php echo esc_attr__( 'Go to Top', 'ecommerce-gigs' )?>" class="fa-angle-up"></a>
    </div>	
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
