<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Ecommerce_Gigs
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <?php ecommerce_gigs_post_thumbnail(); ?>
    <div class="post-content">
        <?php ecommerce_gigs_title(); ?>       
        <div class="entry-content">
            <?php the_content(); ?>
            <?php wp_link_pages( array(
                'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'ecommerce-gigs' ),
                'after'  => '</div>',
            ) );?>
        </div>
    </div>
</article><!-- #post-<?php the_ID(); ?> -->
