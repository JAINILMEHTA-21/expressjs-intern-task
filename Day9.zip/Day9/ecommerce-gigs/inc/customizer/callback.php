<?php 
/**
 * Callback Function
 *
 * @package Ecommerce_Gigs
 */

/**
 * Active callback Top Header 
 */
if ( ! function_exists( 'ecommerce_gigs_callback_top_header' ) ) :

	function ecommerce_gigs_callback_top_header( $control ) { 

		if ( true == $control->manager->get_setting( 'theme_options[enable_top_header]' )->value() ) {
			return true;
		} else {
			return false;
		}
	}

endif;

/**
 * Active callback Top Header Right Menu 
 */
if ( ! function_exists( 'ecommerce_gigs_callback_top_header_right_menu' ) ) :

	function ecommerce_gigs_callback_top_header_right_menu( $control ) { 

		if ( 'menu' == $control->manager->get_setting( 'theme_options[top_header_right]' )->value() ) {
			return true;
		} else {
			return false;
		}
	}

endif;

/**
 * Active callback Top Header Left Menu 
 */
if ( ! function_exists( 'ecommerce_gigs_callback_top_header_left_menu' ) ) :

	function ecommerce_gigs_callback_top_header_left_menu( $control ) { 

		if ( 'menu' == $control->manager->get_setting( 'theme_options[top_header_left]' )->value() ) {
			return true;
		} else {
			return false;
		}
	}

endif;
/**
 * Active callback  Header Vertical Menu 
 */
if ( ! function_exists( 'ecommerce_gigs_callback_header_vertical_menu' ) ) :

	function ecommerce_gigs_callback_header_vertical_menu( $control ) { 

		if ( true == $control->manager->get_setting( 'theme_options[enable_vertical_menu]' )->value() ) {
			return true;
		} else {
			return false;
		}
	}

endif;


/**
 * Active callback Header Address
 */
if ( ! function_exists( 'ecommerce_gigs_header_address' ) ) :

	function ecommerce_gigs_header_address( $control ) { 

		if ( 'address' == $control->manager->get_setting( 'theme_options[top_header_right]' )->value() || 'address' == $control->manager->get_setting( 'theme_options[top_header_left]' )->value() ) {
			return true;
		} else {
			return false;
		}
	}

endif;
/**
 * Active callback Beside Menu
 */
if ( ! function_exists( 'ecommerce_gigs_callback_beside_menu_menu' ) ) :

	function ecommerce_gigs_callback_beside_menu_menu( $control ) { 

		if ( 'menu' == $control->manager->get_setting( 'theme_options[beside_menu]' )->value() ) {
			return true;
		} else {
			return false;
		}
	}

endif;
/**
 * Active callback Beside Menu Address
 */
if ( ! function_exists( 'ecommerce_gigs_callback_beside_menu_address' ) ) :

	function ecommerce_gigs_callback_beside_menu_address( $control ) { 

		if ( 'address' == $control->manager->get_setting( 'theme_options[beside_menu]' )->value() ) {
			return true;
		} else {
			return false;
		}
	}

endif;
/**
 * Active callback Beside Menu Button
 */
if ( ! function_exists( 'ecommerce_gigs_callback_beside_menu_button' ) ) :

	function ecommerce_gigs_callback_beside_menu_button( $control ) { 

		if ( 'button' == $control->manager->get_setting( 'theme_options[beside_menu]' )->value() ) {
			return true;
		} else {
			return false;
		}
	}

endif;
/**
 * Active callback Beside Menu Button and Address 
 */
if ( ! function_exists( 'ecommerce_gigs_callback_beside_menu_address_button' ) ) :

	function ecommerce_gigs_callback_beside_menu_address_button( $control ) { 

		if ( 'address' == $control->manager->get_setting( 'theme_options[beside_menu]' )->value() || 'button' == $control->manager->get_setting( 'theme_options[beside_menu]' )->value() ) {
			return true;
		} else {
			return false;
		}
	}

endif;
/**
 * Active callback  Header Cart
 */
if ( ! function_exists( 'ecommerce_gigs_callback_header_cart' ) ) :

	function ecommerce_gigs_callback_header_cart( $control ) { 

		if ( true == $control->manager->get_setting( 'theme_options[enable_header_cart]' )->value() ) {
			return true;
		} else {
			return false;
		}
	}

endif;
/**
 * Active callback  Header Wishlist
 */
if ( ! function_exists( 'ecommerce_gigs_callback_header_wishlist' ) ) :

	function ecommerce_gigs_callback_header_wishlist( $control ) { 

		if ( true == $control->manager->get_setting( 'theme_options[enable_header_wishlist]' )->value() ) {
			return true;
		} else {
			return false;
		}
	}

endif;