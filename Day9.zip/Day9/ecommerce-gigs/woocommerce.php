<?php
/**
 *
 *
 * The template for displaying woocommerce section.
 *
 * @package Ecommerce_Gigs
 */

get_header();
$woo_sidebar_layout = ecommerce_gigs_get_option( 'woo_sidebar_layout' );
$ecommerce_gigs_woo_classes = 'custom-col-8';
if ( ! is_active_sidebar( 'sidebar-woo' ) || 'no_sidebar'== $woo_sidebar_layout ) {
    $ecommerce_gigs_woo_classes = 'custom-col-12';
    
}
?>
<div class="container">
    <div class="row">
		<main id="primary" class="<?php echo esc_attr( $ecommerce_gigs_woo_classes );?>" >
			<?php woocommerce_content(); ?>
		</main><!-- #main -->
		<?php get_sidebar( 'woo' ); ?>
	</div>
</div>	
<?php
get_footer();