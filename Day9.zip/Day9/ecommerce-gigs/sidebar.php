<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ecommerce_Gigs
 */
global $post;
$sidebar_layout = 'right-sidebar';
if ( is_page() || is_single() ){
        $sidebar_layout = get_post_meta( $post->ID, 'sidebar_options', true ); 
        if ( $sidebar_layout == 'customizer_setting' ){
        	$sidebar_layout = ecommerce_gigs_get_option( 'sidebar_layout' );
        } else{
        	$sidebar_layout = get_post_meta( $post->ID, 'sidebar_options', true ); 
        }
} else{
        $sidebar_layout = ecommerce_gigs_get_option( 'sidebar_layout' );
}
if ( ! is_active_sidebar( 'sidebar-1' ) || 'no_sidebar'== $sidebar_layout ) {
        return;
}
?>

<aside id="secondary" class="widget-area custom-col-4">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- #secondary -->
