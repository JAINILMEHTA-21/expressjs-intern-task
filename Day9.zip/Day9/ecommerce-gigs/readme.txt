=== Ecommerce Gigs ===

Contributors: theme404
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, e-commerce, blog, one-column, two-columns, left-sidebar, right-sidebar, footer-widgets, theme-options
Requires at least: 5.0
Requires PHP: 7.0
Tested up to: 5.7.1
Stable tag: 1.0.3
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Ecommerce Gigs is a free WordPress theme perfectly developed for eCommerce websites of any store type. The theme is fully open up for variant customization options. Moreover, it is smoothly integrated with WooCommerce, one of the most popular eCommerce plugins as well as the Elementor- easy and favored editor. With this theme, you can build fast and responsive sites of different categories, whatever your site is about. However the theme is highly optimized, it won’t prevent you from integrating some major WordPress plugins neither from the compatibility with the popular Gutenberg block editor.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

== License ==

eCommerce Gigs WordPress Theme, Copyright (C) 2021, Themes 404
eCommerce Gigs is distributed under the terms of the GNU GPL

The exceptions to license are as follows:
Fonts
    Font Awesome, maintained by Dave Gandy: SIL OFL 1.1
    https://github.com/FortAwesome/Font-Awesome FontAwesome 4.7.0 Copyright 2012 Dave Gandy Font License: SIL OFL 1.1 Code License: MIT License 
    License Url : http://fontawesome.io/license/ 

Css & JS Files    

    Source: https://github.com/WeCodePixels/theia-sticky-sidebar
    License: The MIT License (MIT) Copyright (c) 2014 Liviu Cristian Mirea Ghiban
    License Url : https://github.com/WeCodePixels/theia-sticky-sidebar/blob/master/LICENSE.txt 

    Source: https://github.com/procurios/ResizeSensor 
    License:  The MIT License (MIT) Copyright (c) 2017 Procurios
    License Url : https://github.com/procurios/ResizeSensor/blob/master/LICENSE  

    Source: https://github.com/cedaro/skip-link-focus 
    License:  The MIT License (MIT)
    License Url : https://github.com/cedaro/skip-link-focus/blob/develop/LICENSE.md

    Source: https://github.com/meanthemes/meanMenu 
    License: GNU LESSER GENERAL PUBLIC LICENSE Copyright (C) 2012-2013 Chris Wharton 
    License Url : https://github.com/meanthemes/meanMenu/blob/master/gpl.txt

    Source: https://github.com/OwlCarousel2/OwlCarousel2
    License: The MIT License (MIT) Copyright (c) 2014 Owl 
    License Url : https://github.com/OwlCarousel2/OwlCarousel2/blob/develop/LICENSE   
   
    
== Screenshots ==
    Image used in screenshot
    Source: https://stocksnap.io/photo/nike-sneakers-53ZL5GR6DC
    License:Creative Commons Zero (CC0) license [ https://stocksnap.io/author/1370 ]
    License Url : https://stocksnap.io/license

    Source: https://stocksnap.io/photo/headphones-music-1IXTRXOWOE
    License: Creative Commons Zero (CC0) license[https://stocksnap.io/author/icons8]
    License Url : https://stocksnap.io/license 
      
    Other images in screenshot are self created and all are under CCO.

    error-bg.jpg
    Source: https://pxhere.com/en/photo/1076506    
    License: Creative Commons Zero (CC0) license.
    License Url : https://pxhere.com/en/license 

    xsearch-icon1.svg    
    Source:  Self Created
    License:  Creative Commons Zero (CC0) license.
    License Url: http://www.gnu.org/licenses/gpl.html

    subscribe-icon1.svg    
    Source:  Self Created
    License:  Creative Commons Zero (CC0) license.
    License Url: http://www.gnu.org/licenses/gpl.html

PHP File          
    TGM Plugin Activation   
    Source: https://github.com/TGMPA/TGM-Plugin-Activation 
    License: GNU General Public License v2.0 Copyright (c) 2011, Thomas Griffin 
    License Url: https://github.com/TGMPA/TGM-Plugin-Activation/blob/develop/LICENSE.md   


= 1.0.0 - April 08 2021 =
    Initial Release

= 1.0.1 - April 19 2021 =   
* Fixed design issue.
* Added keyboard navigation for post meta.
* Fixed keyboard navigation issue with mobile sub menu. 


= 1.0.2 - April 21 2021 = 
* Fixed keyboard navigation for mouse hover while tab is on.
* Change screenshot and added proper image license.

= 1.0.3 - May 06 2021 =
* Added Logo Width Options.
* Added options for Tab & Slider Widget.
* Added Slider Options.
* Added Text align options for footer widget.

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
