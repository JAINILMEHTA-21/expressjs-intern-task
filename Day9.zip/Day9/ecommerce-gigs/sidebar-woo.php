<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ecommerce_Gigs
 */
$woo_sidebar_layout = ecommerce_gigs_get_option( 'woo_sidebar_layout' );
if ( ! is_active_sidebar( 'sidebar-woo' ) || 'no_sidebar'== $woo_sidebar_layout ) {
        return;
}
?>

<aside id="secondary" class="widget-area custom-col-4">
	<?php dynamic_sidebar( 'sidebar-woo' ); ?>
</aside><!-- #secondary -->