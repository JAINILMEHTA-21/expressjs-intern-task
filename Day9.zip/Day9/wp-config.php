<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Dt`E^LRz9rx}Y?Qp?nP)CUl^_$J`FH4lbgu!3Q2OU>;3q@aoY*vmgX^XFF??nc/&' );
define( 'SECURE_AUTH_KEY',  '7s,I#Gjg*%@&j,65Ly=t(jm`26AhsDZ4Z+c{3g%bDS2>8)=,b/s5lYi+I0t9JGce' );
define( 'LOGGED_IN_KEY',    '5?1[H>b|o<hJuGxkT:&XN7fss082Jf8 7I:dB4pBjOK_[kZEB^oAL&iY@eR4;AEi' );
define( 'NONCE_KEY',        '@P[7AV_G8,O_THiG+LP3P:=6*gMws~BqH&6do~d2K6n?6Y[:r]m#U)<dl|c:rY!U' );
define( 'AUTH_SALT',        '9l=o0DyX(esQlCja1Nh[sx^w:.,:w3VzCu`k<W8[dlA>s,[En0OZlmGG:[<)y RO' );
define( 'SECURE_AUTH_SALT', '?ALqBS&#79M:9[@FO_T~fZS[tj}0$%J..A1(P)<k:T~]]YG4Hq9%dv<%O)eL,0d0' );
define( 'LOGGED_IN_SALT',   'm_#12E!p,=o@0/BhEM.^kY$7^QHa5Zfpb6^!*6SBb.sV=zZxJ(yi`$(#[xjcw|qv' );
define( 'NONCE_SALT',       'UB<(k77t1OhFS0;s0P;4#b %Ae7S.0+c#a/s@)B-%Qj4yR^N~0 ]l:+VUAt{HMYk' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
